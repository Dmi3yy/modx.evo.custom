// UK lang variables

tinyMCE.addI18n('zh.clearfloat', {
	button_desc : 'Flow below floated elements'
});
