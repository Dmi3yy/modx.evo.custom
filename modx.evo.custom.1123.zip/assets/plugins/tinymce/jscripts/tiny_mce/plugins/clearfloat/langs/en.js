// UK lang variables

tinyMCE.addI18n('en.clearfloat', {
	button_desc : 'Flow below floated elements'
});
