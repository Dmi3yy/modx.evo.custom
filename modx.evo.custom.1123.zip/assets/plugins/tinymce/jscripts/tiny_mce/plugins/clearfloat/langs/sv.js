// UK lang variables

tinyMCE.addI18n('sv.clearfloat', {
	button_desc : 'Flow below floated elements'
});
