// UK lang variables

tinyMCE.addI18n('pl.clearfloat', {
	button_desc : 'Flow below floated elements'
});
