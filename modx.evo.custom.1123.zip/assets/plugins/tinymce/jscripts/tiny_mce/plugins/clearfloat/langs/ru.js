// UK lang variables

tinyMCE.addI18n('ru.clearfloat', {
	button_desc : 'Flow below floated elements'
});
