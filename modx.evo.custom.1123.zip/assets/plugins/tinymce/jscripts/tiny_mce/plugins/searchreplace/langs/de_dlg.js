tinyMCE.addI18n('de.searchreplace_dlg',{
searchnext_desc:"Weitersuchen",
notfound:"Die Suche ist am Ende angelangt. Die Zeichenkette konnte nicht gefunden werden.",
search_title:"Suchen",
replace_title:"Suchen/Ersetzen",
allreplaced:"Alle Vorkommen der Zeichenkette wurden ersetzt.",
findwhat:"Zu suchender Text",
replacewith:"Ersetzen durch",
direction:"Suchrichtung",
up:"Aufw\u00E4rts",
down:"Abw\u00E4rts",
mcase:"Gro\u00DF-/Kleinschreibung beachten",
findnext:"Weitersuchen",
replace:"Ersetzen",
replaceall:"Alle ersetzen"
});