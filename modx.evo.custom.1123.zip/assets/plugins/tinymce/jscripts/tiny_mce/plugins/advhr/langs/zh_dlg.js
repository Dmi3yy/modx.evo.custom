tinyMCE.addI18n('zh.advhr_dlg',{
width:"\u5BEC\u5EA6",
size:"\u9AD8\u5EA6",
noshade:"\u7121\u9670\u5F71"
});